package org.hojeehdiaderua.beans;

public enum Status {
    SUCCESS, ERROR;
}
